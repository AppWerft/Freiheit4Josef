=== Plugin Name ===
Contributors: Hamburger Appwerft
Tags: FreeJosef
Requires at least: 3.5.1
Tested up to: 3.5.1
Stable tag: 0.3
License: GPLv3

Dieses Plugin bindet die SoliKarte ein.\nWie geht das? In die Seite bindest Du folgenden Code ein: &lt;div id="josefmap" &gt;&lt;/div&gt;

